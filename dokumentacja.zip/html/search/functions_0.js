var searchData=
[
  ['getx_14',['getX',['../class_my_exp.html#a19a59d5fca3c6c86bac8840c868e82ef',1,'MyExp::getX()'],['../myexp_8cpp.html#adc3b511689683dfa42f2848bc12629a5',1,'getX():&#160;myexp.cpp']]]
];
